In realizarea acestui proiect m-am folosit de urmatorele TAD-uri ,de 1 si 6(inital am avut 7 dar s-au schimbat treburile).
1...Acest TAD ,lista am folosit-o pentru a retine la rulare chatu-ul si relatia de prietenie, care poate exista intre 2 useri
6... Acest TAD, Multimea ordonata reprezentata pe un arbore binar de cautare, este cea mai eficienta metoda de a reprezenta
aceasta structura(de multime ordonata).Adaugarea si stergerea se face in O(h), h reprezentand inaltimea
 arborelui ,insa cel mai eficient lucru este cautarea care se realizeaza tot in o(h), care se aproximeaza la O(log(n)).
-M-am folosit de aceasta multime ordonata pentru realizarea evenimentelor si a utilizatorilor.

